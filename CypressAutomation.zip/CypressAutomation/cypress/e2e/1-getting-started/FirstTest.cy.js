//// <reference types = "Cypress"/>

describe('MyTestSuite', function()
{

    it('Verify Title of the page', function()
    {
        cy.visit('https://docs.cypress.io/')
        cy.title().should('eq','Why Cypress? | Cypress Documentation')
    })

    

})