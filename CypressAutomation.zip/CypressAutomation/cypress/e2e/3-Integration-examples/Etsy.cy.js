///<reference types = "Cypress"/>

// describe('MyTestSuite', function()
// {

//     it('Verify Title of the page', function()
//     {
//        // cy.visit('https://docs.cypress.io/')
//        // cy.title().should('eq','Why Cypress? | Cypress Documentation')

//         cy.visit('https://www.etsy.com/')
       
//         cy.contains('Sign in').click()
//         cy.get('.select-register').click()
//         // cy.wait('5000')
     
//         cy.get('#join_neu_email_field').type('osamaf11bb'+Cypress.config('UniqueNumber', `${Math.floor(Math.random() * 1000)}`)+'@gmail.com')
       
//      //   cy.wait('500')
       
//         cy.get('#join_neu_first_name_field').type('Osama sheikh')
//         cy.get('#join_neu_password_field').type('Osa@@915206')
//         cy.get('[type=submit]').contains('Register').click()

//     })

    

// })
// -----------------------------------------------------------------------
describe('MyTestSuite', function()
{

    it('Verify Title of the page', function()
    {
    
        cy.visit('http://automationpractice.com/index.php')
        cy.get('.login').click()
        cy.get('#email').clear().type('osamaS3@gmail.com')
        cy.get('#passwd').clear().type('Osa@@91520669')
        cy.get('#SubmitLogin').click()
        cy.get('.info-account').contains('Welcome to your account.')
        cy.get('li').children().contains('T-shirts').click({force: true})
        cy.scrollTo(0,700)
        cy.get('span').contains('Add to cart').click({force: true})
        
        cy.wait(5000)
        cy.get('h2').contains('Product successfully added to your shopping cart').should('be.visible')
        cy.get('.cross').click({force: true})
        cy.scrollTo(700,0)
        cy.get('.shopping_cart').trigger('mouseover')
        cy.get('.product-name').contains('a').click({force: true})
        cy.scrollTo(0,300)
        cy.get('.icon-plus').click()
        cy.get('span').contains('Add to cart').click({force: true})
        cy.wait(5000)
        cy.get('h2').contains('Product successfully added to your shopping cart').should('be.visible')
        cy.get('.cross').click({force: true})
        cy.get('.shopping_cart').trigger('mouseover')
        cy.get('.remove_link').click({force: true})
        cy.wait(3000)
        cy.get('.shopping_cart').contains('(empty)').should('be.visible')
    })

    

})
