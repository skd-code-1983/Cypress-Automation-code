///<reference types = "Cypress"/>

describe('MyTestSuite', function()
{

    it('Verify An Account is Created', function()
    {
        cy.visit('http://automationpractice.com/index.php')
        cy.get('.login').click()
        cy.scrollTo(0,500)
        cy.get('input[name=email_create]').type('osamaS'+Cypress.config('UniqueNumber',`${Math.floor(Math.random() * 1000)}`)+'@gmail.com')
        cy.get('#SubmitCreate').click()
        
        cy.wait(8000)
        cy.scrollTo(500,200)
        cy.get('#uniform-id_gender1').should('not.be.checked').click()
        cy.get('input[name=customer_firstname]').type('Osama')
        cy.get('input[name=customer_lastname]').type('Sheikh')
        cy.get('input[name=passwd]').type('Osa@@91520669')
        cy.get('input[name=company]').type('Systems Limited')
        cy.get('input[name=address1]').type('KB Home Entrada Del Oro II')
        cy.get('input[name=city]').type('Gold Canyon')
        cy.get('#id_state').select('Arizona').should('have.value','3')
        cy.get('input[name=postcode]').type('85118')
        cy.get('input[name=phone_mobile]').type('090078601')
        cy.get('#alias').type('Pakistan')
        cy.get('#submitAccount').click()
        cy.get('.info-account').contains('Welcome to your account.')

    })

    it('Verify the required fields', function(){
        
        cy.get('.logout').click()
        // cy.get('.page-subheading').contains('Already registered?')
        cy.scrollTo(0,500)
        cy.get('input[name=email_create]').type('osamaS'+Cypress.config('UniqueNumber',`${Math.floor(Math.random() * 1000)}`)+'@gmail.com')
        cy.get('#SubmitCreate').click()
        cy.wait(8000)
        cy.scrollTo(0,1600)
        cy.get('#submitAccount').click()
        cy.wait(2000)
        cy.get('ol').children().should('have.length', 8)

    })
    
    it('Verify Invalid Login Attempt', function(){

        cy.get('.login').click()
        cy.scrollTo(0,300)
        cy.get('#email').type('acb132@gmail.com')
        cy.get('#passwd').type('123qwe')
        cy.get('#SubmitLogin').click()
        cy.get('ol').children().contains('Authentication failed.')
    })

    it('Verify Add/Edit/Delete a Product', function(){

        cy.get('#email').clear().type('osamaS3@gmail.com')
        cy.get('#passwd').clear().type('Osa@@91520669')
        cy.get('#SubmitLogin').click()
        cy.get('.info-account').contains('Welcome to your account.')
        cy.get('li').children().contains('T-shirts').click({force: true})
        cy.scrollTo(0,700)
        cy.get('span').contains('Add to cart').click({force: true})
        
        cy.wait(5000)
        cy.get('h2').contains('Product successfully added to your shopping cart').should('be.visible')
        cy.get('.cross').click({force: true})
        cy.scrollTo(700,0)
        cy.get('.shopping_cart').trigger('mouseover')
        cy.get('.product-name').contains('a').click({force: true})
        cy.scrollTo(0,300)
        cy.get('.icon-plus').click()
        cy.get('span').contains('Add to cart').click({force: true})
        cy.wait(5000)
        cy.get('h2').contains('Product successfully added to your shopping cart').should('be.visible')
        cy.get('.cross').click({force: true})
        cy.get('.shopping_cart').trigger('mouseover')
        cy.get('.remove_link').click({force: true})
        cy.wait(3000)
        cy.get('.shopping_cart').contains('(empty)').should('be.visible')

    })
    

})